// Vorschau-Fassung: eine einzige HTML-Datei mit eingebetteten Geometrien, Schriften und Beispielen
import fs from 'node:fs';
import path from 'node:path';

const dir = 'preview';
const assets = {};
const add = (rel, bin) => { const p = path.join('public', rel); assets[rel.split(path.sep).join('/')] = bin ? fs.readFileSync(p).toString('base64') : fs.readFileSync(p, 'utf8'); };
for (const f of fs.readdirSync('public/data')) add(path.join('data', f), false);
for (const f of fs.readdirSync('public/fonts')) add(path.join('fonts', f), true);
for (const f of fs.readdirSync('public/beispiele')) add(path.join('beispiele', f), true);
let html = fs.readFileSync(path.join(dir, 'index.html'), 'utf8');
const json = JSON.stringify(assets).replace(/</g, '\\u003c');
html = html.replace('<head>', () => `<head>\n<script>window.__KW_ASSETS__=${json};</script>`);
fs.writeFileSync(path.join(dir, 'kartenwerk-preview.html'), html);
for (const d of ['data', 'fonts', 'beispiele']) fs.rmSync(path.join(dir, d), { recursive: true, force: true });
console.log('preview/kartenwerk-preview.html', (html.length / 1024 / 1024).toFixed(2), 'MB');
