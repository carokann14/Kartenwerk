export type Cell = string | number | null;
export type Role = 'id' | 'name' | 'value' | 'category' | 'label' | 'ignore';
export type PresetId = 'auto' | 'bwl-kerg' | 'bwl-kerg2' | 'bwl-umrechnung' | 'allgemein';

export interface Column { id: string; label: string; kind: 'number' | 'text'; role: Role; party: string | null; short: string | null }
export interface Group { id: string; label: string; columns: string[]; total: string | null; parties: boolean }

export interface LongSettings { key: number; name: number | null; group: number; sub: number | null; value: number; kind: number | null; filterCol: number | null; filterValue: string }
export interface GroupSetting { label: string; columns: string[]; total: string | null; parties: boolean }
export interface ImportSettings {
  preset: PresetId;
  sheet: number;
  headerStart: number;
  headerRows: number;
  format: 'wide' | 'long';
  long: LongSettings | null;
  roles: Record<string, 'id' | 'name' | 'value' | 'category' | 'label' | 'ignore'>;
  groups: GroupSetting[] | null;
  geoSet: string;
  dashIsZero: boolean;
  excludeSummary: boolean;
  rules: Record<string, string | null>;
  sourceTitle: string;
  attribution: string;
}

export type IssueKind = 'byName' | 'ambiguous' | 'unknown' | 'duplicate';
export interface MatchIssue { row: number; kind: IssueKind; key: string; name: string; candidates: string[]; chosen: string | null }
export interface MatchReport {
  total: number; exact: number; byName: number; ambiguous: number; unknown: number; duplicate: number;
  summary: number; ignored: number; ruled: number;
  missing: string[];
  nameMismatch: { row: number; areaId: string; dataName: string; geoName: string }[];
  issues: MatchIssue[];
  nullCells: number; dashCells: number;
}

export interface Dataset {
  id: string;
  name: string;
  fileName: string;
  importedAt: string;
  geoSet: string;
  preset: PresetId;
  settings: ImportSettings;
  columns: Column[];
  groups: Group[];
  rows: Cell[][];
  rowKey: string[];
  rowArea: (string | null)[];
  report: MatchReport;
}

export interface RawSheet { name: string; cells: Cell[][] }
export interface RawInput { fileName: string; kind: 'csv' | 'xlsx'; sheets: RawSheet[]; encoding: string; delimiter: string }
